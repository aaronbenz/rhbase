library(testthat)
library(rhbase)

test_check("rhbase")
